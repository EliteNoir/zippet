def add(a,b):
    return a+b

def sustrat(a,b):
    return a-b

def multiple(a,b):
    return a*b

def div(a,b):
    return a//b

def carre(a):
    return a**2
