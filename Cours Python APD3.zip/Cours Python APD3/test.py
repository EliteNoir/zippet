4+6
5-2
10/2
print(2*10)
print(sylla)
print("salut sylla")
